package com.app.url.panel.right;

import java.awt.BorderLayout;
import java.awt.LayoutManager;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import com.app.url.main.UrlMainWindow;

public class UrlRightMiddlePanel extends JPanel {
	public static JTextArea textarea;

	public UrlRightMiddlePanel(UrlMainWindow mainWindow, UrlRightPanel urlRightPanel) {
		this();
	}

	public UrlRightMiddlePanel() {
		super();
		textarea = new JTextArea(10, 80);
		JScrollPane Pane = new JScrollPane(textarea);
		// add(textarea);
		// this.setVisible(true);
		setLayout(new BorderLayout());
		add(Pane, BorderLayout.CENTER);
	}

	public UrlRightMiddlePanel(boolean isDoubleBuffered) {
		super(isDoubleBuffered);

	}

	public UrlRightMiddlePanel(LayoutManager layout, boolean isDoubleBuffered) {
		super(layout, isDoubleBuffered);

	}

	public UrlRightMiddlePanel(LayoutManager layout) {
		super(layout);

	}

}
