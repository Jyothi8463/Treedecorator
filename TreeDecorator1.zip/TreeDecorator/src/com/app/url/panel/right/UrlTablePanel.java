package com.app.url.panel.right;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringJoiner;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.app.url.actionui.FileExportAction;
import com.app.url.main.UrlMainWindow;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class UrlTablePanel extends JPanel {
	public static DefaultTableModel tableModel;
	public static JTable table;
	private static Object columnNames[] = { "Url Request", "Response Code", "Response String"};
	private static Object rowData[][];
	JScrollPane pane = null;
	private static JButton Button;

	public UrlTablePanel(UrlMainWindow mainWindow, UrlRightPanel urlRightPanel) {
		// Object rowData[][] = { { "Row1-Column1", "Row1-Column2",
		// "Row1-Column3" },
		// { "Row2-Column1", "Row2-Column2", "Row2-Column3" } };
		// JPanel panel1 = new JPanel();
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		JPanel panel = new JPanel(new FlowLayout());
		tableModel = new DefaultTableModel(columnNames, 0);
		table = new JTable(tableModel);
		pane = new JScrollPane(table);
		panel.setLayout(new BorderLayout());
		pane.setPreferredSize(new Dimension(500, 200));
		panel.add(pane, BorderLayout.CENTER);
		add(panel);
		// setVisible(true);
		JPanel panel1 = new JPanel(new FlowLayout());
		Button = new JButton("Export");
		Button.addActionListener(new FileExportAction());

		panel1.setLayout(new FlowLayout());
		panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
		panel1.add(Button, BorderLayout.SOUTH);
		add(panel1);

	}


    public static void exportTable(JTable table) throws IOException {
    	  JFileChooser chooser = new JFileChooser();
          chooser.showSaveDialog(null);
    	File file = null;
    	 file = chooser.getSelectedFile();
     /*   try (BufferedWriter bufferWriter = new BufferedWriter(new FileWriter(file))) {
        	StringJoiner stringJoiner = new StringJoiner(",");
            for (int i = 0; i <tableModel.getColumnCount(); i++) {
            	stringJoiner.add(tableModel.getColumnName(i));
            }
            bufferWriter.write(stringJoiner.toString());
            bufferWriter.newLine();
            for (int i = 0; i < tableModel.getRowCount(); i++) {
            	stringJoiner = new StringJoiner(",");
                for (int j = 0; j < tableModel.getColumnCount(); j++) {
                	stringJoiner.add(tableModel.getValueAt(i, j).toString());
                }
                bufferWriter.write("\""+stringJoiner.toString()+"\"");
                bufferWriter.newLine();
            }
            System.out.println("write out to: " + file);
        }*/
    	 
    	
      /*   FileWriter out = new FileWriter(file);
        
        for(int i=0; i < tableModel.getColumnCount(); i++) {
            out.write(tableModel.getColumnName(i) + "\t");
        }
        out.write("\n");
        for(int i=0; i< tableModel.getRowCount(); i++) {
            for(int j=0; j < tableModel.getColumnCount(); j++) {
            //    out.write(tableModel.getValueAt(i,j).toString()+"\t");
                 out.write("\""+tableModel.getValueAt(i, j).toString()+"\t"+"\"");
            }
            out.write("\n");
        }
        out.close();
        System.out.println("write out to: " + file);*/
    	 

         try {

             WritableWorkbook workbook = Workbook.createWorkbook(file);
             WritableSheet sheet = workbook.createSheet("Sheet", 0); 

             for (int i = 0; i < tableModel.getColumnCount(); i++) {
                 Label column = new Label(i, 0,tableModel.getColumnName(i) + "\t");
                 sheet.addCell(column);
             }
             int j = 0;
             for (int i = 0; i < tableModel.getRowCount(); i++) {
                 for (j = 0; j < tableModel.getColumnCount(); j++) {
                     Label row = new Label(j, i + 1, 
                    		 tableModel.getValueAt(i, j).toString()+"\t");
                     sheet.addCell(row);
                 }
             }
             workbook.write();
             workbook.close();
         } catch (Exception ex) {
             ex.printStackTrace();
         }
         System.out.println("write out to: " + file);
    }
	
	public UrlTablePanel() {
		super();

	}

	public UrlTablePanel(boolean arg0) {
		super(arg0);

	}

	public UrlTablePanel(LayoutManager arg0, boolean arg1) {
		super(arg0, arg1);

	}

	public UrlTablePanel(LayoutManager arg0) {
		super(arg0);

	}

	/**
	 * @return the tableModel
	 */
	public static DefaultTableModel getTableModel() {
		return tableModel;
	}

	/**
	 * @param tableModel
	 *            the tableModel to set
	 */
	public static void setTableModel(DefaultTableModel tableModel) {
		UrlTablePanel.tableModel = tableModel;
	}

	/**
	 * @return the table
	 */
	public static JTable getTable() {
		return table;
	}

	/**
	 * @param table
	 *            the table to set
	 */
	public static void setTable(JTable table) {
		UrlTablePanel.table = table;
	}

	/**
	 * @return the columnNames
	 */
	public static Object[] getColumnNames() {
		return columnNames;
	}

	/**
	 * @param columnNames
	 *            the columnNames to set
	 */
	public static void setColumnNames(Object[] columnNames) {
		UrlTablePanel.columnNames = columnNames;
	}

	/**
	 * @return the rowData
	 */
	public static Object[][] getRowData() {
		return rowData;
	}

	/**
	 * @param rowData
	 *            the rowData to set
	 */
	public static void setRowData(Object[][] rowData) {
		UrlTablePanel.rowData = rowData;
	}

	/**
	 * @return the pane
	 */
	public JScrollPane getPane() {
		return pane;
	}

	/**
	 * @param pane
	 *            the pane to set
	 */
	public void setPane(JScrollPane pane) {
		this.pane = pane;
	}

}
