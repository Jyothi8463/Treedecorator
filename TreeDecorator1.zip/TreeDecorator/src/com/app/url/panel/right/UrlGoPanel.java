package com.app.url.panel.right;

import java.awt.FlowLayout;
import java.awt.event.KeyEvent;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.app.url.actionui.UrlGoAction;
import com.app.url.main.UrlMainWindow;

public class UrlGoPanel extends JPanel {

	private UrlMainWindow main;
	private UrlRightPanel parentWindow;

	public static JTextField textField;
	private static JButton goButton;
	public static JTextField headerTextField;
	public static JTextField UrlField;
	public static JTextField countField;
	public static JButton Button1;


	public UrlGoPanel() {
		super();

		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		JPanel panel = new JPanel(new FlowLayout());
		JLabel label = new JLabel("URL Field: ");
		label.setDisplayedMnemonic(KeyEvent.VK_N);
		textField = new JTextField(50);
		textField.setHorizontalAlignment(JTextField.LEFT);
		textField.setToolTipText("Enter the URL");
		textField.setSize(getPreferredSize());
		// panel.setBounds(61, 11, 81, 140);
		label.setLabelFor(textField);
		// label.set
		panel.add(label);// , BorderLayout.WEST);
		panel.add(textField);// , BorderLayout.EAST);
		// panel.setPreferredSize(new Dimension(panel2.getWidth(),
		// textField.getHeight() + 50));

		goButton = new JButton("Go");
		goButton.addActionListener(new UrlGoAction());
		panel.add(goButton);
		panel.setLayout(new FlowLayout());
		panel.setLayout(new FlowLayout(FlowLayout.LEFT));
		add(panel);

		JPanel panel2 = new JPanel(new FlowLayout());
		countField = new JTextField(5);
	//	countField.setText("");
		countField.setToolTipText("Place  your count of url's to print");
		countField.setHorizontalAlignment(JTextField.CENTER);
	//	 countField.addActionListener(new UrlGoAction().CountField());
		JLabel label2 = new JLabel("URL Count Field: ");
		label2.setDisplayedMnemonic(KeyEvent.VK_N);
		label2.setLabelFor(countField);
		panel2.add(label2);
		panel2.add(countField);
	/*	
		Button1 = new JButton("Go ");
		//Button1.addActionListener(new UrlGoAction().CountField());
		Button1.addActionListener(new FileCountAction());
		panel2.add(Button1);
		*/
		panel2.setLayout(new FlowLayout());
		panel2.setLayout(new FlowLayout(FlowLayout.LEFT));
		add(panel2);

		JPanel panel1 = new JPanel(new FlowLayout());
		JLabel label1 = new JLabel("X-Cloupia-Request-Key: ");
		headerTextField = new JTextField(50);
		headerTextField.setText("");
		headerTextField.setToolTipText("Place  your rest api access key");
		headerTextField.setHorizontalAlignment(JTextField.CENTER);
		label1.setLabelFor(headerTextField);
		panel1.add(label1);
		panel1.add(headerTextField);
		panel1.setLayout(new FlowLayout());
		panel1.setLayout(new FlowLayout(FlowLayout.LEFT));
		add(panel1);

	}

	
	public UrlGoPanel(UrlMainWindow mainWindow, UrlRightPanel urlRightPanel) {

		this();
		setMain(mainWindow);
		setParentWindow(urlRightPanel);

	}

	/**
	 * @return the main
	 */
	public UrlMainWindow getMain() {
		return main;
	}

	/**
	 * @param main
	 *            the main to set
	 */
	public void setMain(UrlMainWindow main) {
		this.main = main;
	}

	/**
	 * @return the textField
	 */
	public static JTextField getTextField() {
		return textField;
	}

	/**
	 * @param textField
	 *            the textField to set
	 */
	public static void setTextField(JTextField textField) {
		UrlGoPanel.textField = textField;
	}

	/**
	 * @return the goButton
	 */
	public static JButton getGoButton() {
		return goButton;
	}

	/**
	 * @param goButton
	 *            the goButton to set
	 */
	public static void setGoButton(JButton goButton) {
		UrlGoPanel.goButton = goButton;
	}

	/**
	 * @return the parentWindow
	 */
	public UrlRightPanel getParentWindow() {
		return parentWindow;
	}

	/**
	 * @param parentWindow
	 *            the parentWindow to set
	 */
	public void setParentWindow(UrlRightPanel parentWindow) {
		this.parentWindow = parentWindow;
	}

	/**
	 * @return the headerTextField
	 */
	public static JTextField getHeaderTextField() {
		return headerTextField;
	}

	/**
	 * @param headerTextField
	 *            the headerTextField to set
	 */
	public static void setHeaderTextField(JTextField headerTextField) {
		UrlGoPanel.headerTextField = headerTextField;
	}

	/**
	 * @return the countField
	 */
	public static JTextField getCountField() {
		return countField;
	}

	/**
	 * @param countField
	 *            the countField to set
	 */
	public static void setCountField(JTextField countField) {
		UrlGoPanel.countField = countField;
	}
	/**
	 * @return the urlField
	 */
	public static JTextField getUrlField() {
		return UrlField;
	}

	/**
	 * @param urlField the urlField to set
	 */
	public static void setUrlField(JTextField urlField) {
		UrlGoPanel.UrlField = urlField;
	}

	/**
	 * @return the button1
	 */
	public static JButton getButton1() {
		return Button1;
	}

	/**
	 * @param button1 the button1 to set
	 */
	public static void setButton1(JButton button1) {
		UrlGoPanel.Button1 = button1;
	}

}
