/**
 * 
 */
package com.app.url.panel.right;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

import com.app.url.main.UrlMainWindow;

/**
 * @author lkandasa
 *
 */
public class UrlRightPanel extends JPanel {

	private static UrlGoPanel urlGoPanel;
	private static UrlRightMiddlePanel urlMiddlePanel;
	private static UrlTablePanel urlTablePanel;
	private static UrlMainWindow mainWindow;

	public UrlRightPanel(UrlMainWindow urlMainWindow) {
		this();
		setMainWindow(urlMainWindow);
		
	}

	public UrlRightPanel() {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		urlGoPanel = new UrlGoPanel(mainWindow, this);
		add(urlGoPanel);

		urlMiddlePanel = new UrlRightMiddlePanel(mainWindow, this);
		add(urlMiddlePanel);

		urlTablePanel = new UrlTablePanel(mainWindow, this);
		add(urlTablePanel);
	}

	/**
	 * @return the urlGoPanel
	 */
	public static UrlGoPanel getUrlGoPanel() {
		return urlGoPanel;
	}

	/**
	 * @param urlGoPanel
	 *            the urlGoPanel to set
	 */
	public static void setUrlGoPanel(UrlGoPanel urlGoPanel) {
		UrlRightPanel.urlGoPanel = urlGoPanel;
	}

	/**
	 * @return the urlMiddlePanel
	 */
	public static UrlRightMiddlePanel getUrlMiddlePanel() {
		return urlMiddlePanel;
	}

	/**
	 * @param urlMiddlePanel
	 *            the urlMiddlePanel to set
	 */
	public static void setUrlMiddlePanel(UrlRightMiddlePanel urlMiddlePanel) {
		UrlRightPanel.urlMiddlePanel = urlMiddlePanel;
	}

	/**
	 * @return the urlTablePanel
	 */
	public static UrlTablePanel getUrlTablePanel() {
		return urlTablePanel;
	}

	/**
	 * @param urlTablePanel
	 *            the urlTablePanel to set
	 */
	public static void setUrlTablePanel(UrlTablePanel urlTablePanel) {
		UrlRightPanel.urlTablePanel = urlTablePanel;
	}

	/**
	 * @return the mainWindow
	 */
	public static UrlMainWindow getMainWindow() {
		return mainWindow;
	}

	/**
	 * @param mainWindow
	 *            the mainWindow to set
	 */
	public static void setMainWindow(UrlMainWindow mainWindow) {
		UrlRightPanel.mainWindow = mainWindow;
	}

}
