package com.app.url.panel;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import com.app.url.main.UrlMainWindow;
import com.app.url.tree.UrlTree;

public class UrlLeftPanel extends JPanel {
	private static UrlTree urlTree;
	private static UrlMainWindow parentWindow;

	public UrlLeftPanel(UrlMainWindow urlMainWindow) {
		this();
		setParentWindow(urlMainWindow);
		// create the root node
		// DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("Url Root");
		DefaultTreeModel treeModel = new DefaultTreeModel(root);

		urlTree = new UrlTree(urlMainWindow, this, treeModel);
		setUrlTree(urlTree);
		// add(urlTree);

		JScrollPane Pane = new JScrollPane(urlTree);
		setLayout(new BorderLayout());
		Pane.setPreferredSize(new Dimension(200, 200));
		add(Pane);

	}

	public UrlLeftPanel() {
		super();

	}

	/**
	 * @return the urlTree
	 */
	public static UrlTree getUrlTree() {
		return urlTree;
	}

	/**
	 * @param urlTree
	 *            the urlTree to set
	 */
	public static void setUrlTree(UrlTree urlTree) {
		UrlLeftPanel.urlTree = urlTree;
	}

	/**
	 * @return the parentWindow
	 */
	public static UrlMainWindow getParentWindow() {
		return parentWindow;
	}

	/**
	 * @param parentWindow
	 *            the parentWindow to set
	 */
	public static void setParentWindow(UrlMainWindow parentWindow) {
		UrlLeftPanel.parentWindow = parentWindow;
	}

}
