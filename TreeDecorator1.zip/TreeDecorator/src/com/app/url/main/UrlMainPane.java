package com.app.url.main;

import java.awt.Component;

import javax.swing.JSplitPane;

import com.app.url.panel.UrlLeftPanel;
import com.app.url.panel.right.UrlRightPanel;

public class UrlMainPane extends JSplitPane {

	

	public UrlMainPane() {
		super();
		
	}

	public UrlMainPane(int arg0, boolean arg1, Component arg2, Component arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

	public UrlMainPane(int arg0, boolean arg1) {
		super(arg0, arg1);
		
	}

	public UrlMainPane(int arg0, Component arg1, Component arg2) {
		super(arg0, arg1, arg2);
		System.out.println("UrlMainPane constructor ..................");
		setOneTouchExpandable(true);
	}

	public UrlMainPane(int arg0) {
		super(arg0);
		
	}

}
