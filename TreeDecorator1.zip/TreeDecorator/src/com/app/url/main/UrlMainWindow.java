package com.app.url.main;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.plaf.metal.MetalTheme;
import com.app.url.actionui.FileCloseAction;
import com.app.url.actionui.FileDeleteAction;
import com.app.url.actionui.FileExitAction;
import com.app.url.actionui.FileExportAction;
import com.app.url.actionui.FileImportAction;
import com.app.url.actionui.FileNewAction;
import com.app.url.actionui.FileOpenAction;
import com.app.url.actionui.FileSaveAction;
import com.app.url.actionui.FileSaveAsAction;
import com.app.url.panel.UrlLeftPanel;
import com.app.url.panel.right.UrlRightPanel;
import com.app.url.util.ui.EditUserPreferencesAction;
import com.app.url.util.ui.GeneralLookPreferencesEditor;
import com.app.url.util.ui.PreferencesEditor;
import com.app.url.util.ui.Theme;
import com.app.url.util.ui.UiUtil;

public class UrlMainWindow {

	/** Principal window for this application. */
	public static JFrame fFrame;

	private Action fExitAction;
	private Action fEditUserPreferencesAction;
	private Action fFileNewAction;
	private Action fFileOpenAction;
	private Action fFileCloseAction;
	private Action fFileSaveAction;
	private Action fFileSaveAsAction;
	private Action fFileDeleteAction;
	private Action fFileImportAction;
	private Action fFileExportAction;
	private JToolBar fToolbar;

	/**
	 * The preferred size of the panel which contains both fQuoteTable and
	 * fSummaryView. Determines the overall size of the main window. If this was
	 * not provided, then the main window would appear a bit too large, and on
	 * Windows the bottom of the window would be cut off by the task bar.
	 */
	
	private static final Dimension MAIN_PANEL_SIZE = new Dimension(400, 300);
	private static final String ICON = "favicon.gif";
	// private static final Logger fLogger =
	// Util.getLogger(StocksMonitorMainWindow.class);

	/** Construct this application's main window. */
	public UrlMainWindow() {
		/*
		 * Implementation Note: There are strong order dependencies in these
		 * method calls. For example, Action objects need to be built before
		 * they can be used to build the menu and toolbar.
		 */
		initGuiPieces();
		initFrame();
		initActions();
		initMainGui();
		showMainWindow();
	}

	private JMenuBar getMenuBar() {
		JMenuBar menubar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		fileMenu.add(fFileNewAction);
		fileMenu.add(fFileOpenAction);
		fileMenu.add(fFileCloseAction);
		fileMenu.addSeparator();
		fileMenu.add(fFileSaveAction);
		fileMenu.add(fFileSaveAsAction);
		fileMenu.add(fFileDeleteAction);
		fileMenu.addSeparator();
		fileMenu.add(fFileImportAction);
		fileMenu.add(fFileExportAction);
		fileMenu.add(fEditUserPreferencesAction);
		fileMenu.addSeparator();
		// fileMenu.add(new ImportAction(fFrame));
		// fileMenu.add(new ExportAction(fFrame));
		fileMenu.addSeparator();
		fileMenu.add(fExitAction);
		menubar.add(fileMenu);

		JMenu editMenu = new JMenu("Edit");
		editMenu.setMnemonic(KeyEvent.VK_E);
		// editMenu.add(new EditPortfolioAction(fCurrentPortfolio, fFrame));
		// editMenu.add(fFetchQuotesAction);
		menubar.add(editMenu);

		JMenu helpMenu = new JMenu("Help");
		helpMenu.setMnemonic(KeyEvent.VK_H);
		// helpMenu.add(new HelpAction(fFrame, "Contents", KeyEvent.VK_C, null,
		// HelpAction.View.CONTENTS));
		// helpMenu.add(new HelpAction(fFrame, "Index", KeyEvent.VK_I, null,
		// HelpAction.View.INDEX));
		// helpMenu.add(new HelpAction(fFrame, "Search...", KeyEvent.VK_S, null,
		// HelpAction.View.SEARCH));
		helpMenu.add(new JSeparator());
		// helpMenu.add(new AboutAction(fFrame));

		menubar.add(helpMenu);
		return menubar;
	}

	private JToolBar getToolBar() {
		JToolBar toolbar = new JToolBar();
		// toolbar.setFloatable(false);
		toolbar.setRollover(true);

		toolbar.add(fFileNewAction);
		toolbar.add(fFileOpenAction);
		toolbar.add(fFileSaveAction);
		toolbar.add(fFileSaveAsAction);
		toolbar.add(fFileDeleteAction);

		toolbar.addSeparator();
		// toolbar.add(fFetchQuotesAction);

		// SWING BUG?: this toolbar button does not perform the same action
		// as the corresponding menu item (it fails with the cryptic message
		// "trouble in HelpActionListener").
		// toolbar.addSeparator();
		// toolbar.add( fHelpContentsAction );
		return toolbar;
	}

	private void initFrame() {
		fFrame = new JFrame();
		// Note that this is *not* set ; see use of fExitAction below
		// fFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon imageIcon = UiUtil.getImageIcon(ICON, this.getClass());
		fFrame.setIconImage(imageIcon.getImage());
		// use the default BorderLayout
	}

	private void initActions() {
		System.out.println("Initializing Actions.");
		fFileDeleteAction = new FileDeleteAction(fFrame);
		fFileSaveAction = new FileSaveAction("");
		fFileNewAction = new FileNewAction("", fFrame);
		fFileSaveAsAction = new FileSaveAsAction("", fFrame);
		fFileOpenAction = new FileOpenAction("", fFrame);
		fFileCloseAction = new FileCloseAction("");

		// fFileSaveAsAction = new FileSaveAsAction( "");
		// EditSaver editSaver = new EditSaver(fFileSaveAction,
		// fFileSaveAsAction, fFrame);
		// fFileNewAction = new FileNewAction(fFrame, "");
		// fFileCloseAction = new FileCloseAction( "",fFrame);

		java.util.List<PreferencesEditor> prefEditors = new ArrayList<>();
		// prefEditors.add(fGeneralLookPrefs);
		// prefEditors.add(new LoggingPreferencesEditor());
		// prefEditors.add(fQuoteTablePrefsEditor);
		fEditUserPreferencesAction = new EditUserPreferencesAction(fFrame, prefEditors);
		fFileImportAction = new FileImportAction("", fFrame);
		fFileExportAction = new FileExportAction();
		fExitAction = new FileExitAction("");

		// fFetchQuotesAction = new FetchQuotesAction(fCurrentPortfolio,
		// fQuoteTablePrefsEditor, fQuoteTable,
		// fSummaryView);
		// fFetchQuotesAction.startTimer();
	}

	private void initMainGui() {
		/*
		 * Implementation Note: Default tab order simply reflects the order in
		 * which items are added to the container.
		 */
		System.out.println("Initializing larges pieces of the GUI.");

		UrlMainPane splitPane = new UrlMainPane(JSplitPane.HORIZONTAL_SPLIT, new UrlLeftPanel(this),
				new UrlRightPanel(this));

		fFrame.setJMenuBar(getMenuBar());
		fToolbar = getToolBar();
		fFrame.getContentPane().add(fToolbar, BorderLayout.NORTH);
		fFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
		fFrame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				fExitAction.actionPerformed(null);
			}
		});
	}

	/**
	 * Allows end user to edit preferences for the general look and feel of the
	 * application, and allows programmatic, read-only access to these
	 * preferences as well.
	 */
	private GeneralLookPreferencesEditor fGeneralLookPrefs;

	private void showMainWindow() {
		System.out.println("Showing the main window.");
		// For Themes with large fonts, the quote table column headers are not
		// being rendered properly upon startup: the color and font size are no
		// different
		// from the defaults. This *may* be a Swing bug since all other items
		// are
		// rendered correctly. In the case of Themes with large fonts, a repaint
		// is used to correct the problem.
		// (As a further data point, the column headers are correctly rendered
		// when the user changes Theme through the preferences dialog; thus,
		// the problem is only seen upon startup.)

		if (!Theme.hasLargeFont(fGeneralLookPrefs.getTheme())) {
			// no repaint occurs here
			synchGuiWithGeneralLookPrefs();
			UiUtil.centerAndShow(fFrame);
		} else {
			// forces a repaint to occur
			UiUtil.centerAndShow(fFrame);
			synchGuiWithGeneralLookPrefs();
		}
	}

	private void synchGuiWithGeneralLookPrefs() {
		if (fGeneralLookPrefs.hasShowToolBar()) {
			fToolbar.setVisible(true);
		} else {
			/*
			 * Implementation Note If the toolbar is made invisible while it
			 * still has the focus, then bad things happen : the user cannot
			 * immediately access the menu through the keyboard, nor does the
			 * TAB key change the focus. So, it is important that the toolbar
			 * give up the focus before it is made invisible. Here, this is done
			 * by having the tree request focus.
			 */
			// fQuoteFilterFactory.requestFocusInWindow();
			fToolbar.setVisible(false);
		}

		MetalTheme preferredTheme = fGeneralLookPrefs.getTheme();
		MetalLookAndFeel.setCurrentTheme(preferredTheme);
		try {
			UIManager.setLookAndFeel(new MetalLookAndFeel());
		} catch (UnsupportedLookAndFeelException ex) {
			// fLogger.severe("Cannot set new Theme for Java Look and Feel.");
		}

		SwingUtilities.updateComponentTreeUI(fFrame);

		fFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	private void initGuiPieces() {
		fGeneralLookPrefs = new GeneralLookPreferencesEditor();
		// fGeneralLookPrefs.addObserver(this);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	/**
	 * @return the fFrame
	 */
	public JFrame getfFrame() {
		return fFrame;
	}

	/**
	 * @param fFrame
	 *            the fFrame to set
	 */
	public void setfFrame(JFrame fFrame) {
		this.fFrame = fFrame;
	}

	/**
	 * @return the fExitAction
	 */
	public Action getfExitAction() {
		return fExitAction;
	}

	/**
	 * @param fExitAction
	 *            the fExitAction to set
	 */
	public void setfExitAction(Action fExitAction) {
		this.fExitAction = fExitAction;
	}

	/**
	 * @return the fEditUserPreferencesAction
	 */
	public Action getfEditUserPreferencesAction() {
		return fEditUserPreferencesAction;
	}

	/**
	 * @param fEditUserPreferencesAction
	 *            the fEditUserPreferencesAction to set
	 */
	public void setfEditUserPreferencesAction(Action fEditUserPreferencesAction) {
		this.fEditUserPreferencesAction = fEditUserPreferencesAction;
	}

	/**
	 * @return the fFileNewAction
	 */
	public Action getfFileNewAction() {
		return fFileNewAction;
	}

	/**
	 * @param fFileNewAction
	 *            the fFileNewAction to set
	 */
	public void setfFileNewAction(Action fFileNewAction) {
		this.fFileNewAction = fFileNewAction;
	}

	/**
	 * @return the fFileOpenAction
	 */
	public Action getfFileOpenAction() {
		return fFileOpenAction;
	}

	/**
	 * @param fFileOpenAction
	 *            the fFileOpenAction to set
	 */
	public void setfFileOpenAction(Action fFileOpenAction) {
		this.fFileOpenAction = fFileOpenAction;
	}

	/**
	 * @return the fFileCloseAction
	 */
	public Action getfFileCloseAction() {
		return fFileCloseAction;
	}

	/**
	 * @param fFileCloseAction
	 *            the fFileCloseAction to set
	 */
	public void setfFileCloseAction(Action fFileCloseAction) {
		this.fFileCloseAction = fFileCloseAction;
	}

	/**
	 * @return the fFileSaveAction
	 */
	public Action getfFileSaveAction() {
		return fFileSaveAction;
	}

	/**
	 * @param fFileSaveAction
	 *            the fFileSaveAction to set
	 */
	public void setfFileSaveAction(Action fFileSaveAction) {
		this.fFileSaveAction = fFileSaveAction;
	}

	/**
	 * @return the fFileSaveAsAction
	 */
	public Action getfFileSaveAsAction() {
		return fFileSaveAsAction;
	}

	/**
	 * @param fFileSaveAsAction
	 *            the fFileSaveAsAction to set
	 */
	public void setfFileSaveAsAction(Action fFileSaveAsAction) {
		this.fFileSaveAsAction = fFileSaveAsAction;
	}

	/**
	 * @return the fFileDeleteAction
	 */
	public Action getfFileDeleteAction() {
		return fFileDeleteAction;
	}

	/**
	 * @param fFileDeleteAction
	 *            the fFileDeleteAction to set
	 */
	public void setfFileDeleteAction(Action fFileDeleteAction) {
		this.fFileDeleteAction = fFileDeleteAction;
	}

	/**
	 * @return the fFileImportAction
	 */

	public Action getfFileImportAction() {
		return fFileImportAction;
	}

	/**
	 * @param fFileImportAction
	 *            the fFileImportAction to set
	 */
	public void setfFileImportAction(Action fFileImportAction) {
		this.fFileImportAction = fFileImportAction;
	}

	/**
	 * @return the fFileExportAction
	 */
	public Action getfFileExportAction() {
		return fFileExportAction;
	}

	/**
	 * @param fFileExportAction the fFileExportAction to set
	 */
	public void setfFileExportAction(Action fFileExportAction) {
		this.fFileExportAction = fFileExportAction;
	}
	
	/**
	 * @return the fToolbar
	 */
	public JToolBar getfToolbar() {
		return fToolbar;
	}

	/**
	 * @param fToolbar
	 *            the fToolbar to set
	 */
	public void setfToolbar(JToolBar fToolbar) {
		this.fToolbar = fToolbar;
	}

	/**
	 * @return the fGeneralLookPrefs
	 */
	public GeneralLookPreferencesEditor getfGeneralLookPrefs() {
		return fGeneralLookPrefs;
	}

	/**
	 * @param fGeneralLookPrefs
	 *            the fGeneralLookPrefs to set
	 */
	public void setfGeneralLookPrefs(GeneralLookPreferencesEditor fGeneralLookPrefs) {
		this.fGeneralLookPrefs = fGeneralLookPrefs;
	}

	/**
	 * @return the mainPanelSize
	 */
	public static Dimension getMainPanelSize() {
		return MAIN_PANEL_SIZE;
	}

	/**
	 * @return the icon
	 */
	public static String getIcon() {
		return ICON;
	}

}
