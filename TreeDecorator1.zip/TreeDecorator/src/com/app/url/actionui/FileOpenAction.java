package com.app.url.actionui;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.KeyStroke;

import com.app.url.util.ui.UiUtil;

public final class FileOpenAction extends AbstractAction {

  /**
  * Constructor.
  *  
  * @param aCurrentPortfolio is updated by this action.
  * @param aFrame the parent window
  * @param aEditSaver allows the user to save any unsaved edits of the old
  * <tt>CurrentPortfolio</tt> being replaced by this action.
  */
  public FileOpenAction(String name,  JFrame aFrame) {
 //   super("Open", UiUtil.getImageIcon("/toolbarButtonGraphics/general/Open")); 
	  super("Open", UiUtil.getEmptyIcon());
    
    putValue(SHORT_DESCRIPTION, "Open an existing portfolio");
    putValue(
      ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK)
    );
    putValue(LONG_DESCRIPTION, "Open an existing portfolio with a given name");
    putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_O) );    
  }

  @Override public void actionPerformed(ActionEvent event) {
   
    showDialog();
  }  

  

  /** Allow user to select the desired portfolio from a list.  */
  private void showDialog(){
    String selectedName = askForSelectedPortfolio();
    if ( selectedName != null ) {
      openPortfolio(selectedName);
    }
  }
  
  /**
  * Returns the user selection for an existing Portfolio name, as selected from an 
  * alphabetical list.
  * 
  * If user hits Cancel button or closes the frame, then null is returned. If 
  * the user hits OK without making a selection, then the first item in the 
  * list is returned.
  */
  private String askForSelectedPortfolio(){
   
    return "";
  }

  private void openPortfolio(String aSelectedName ){
    
  }
}
