package com.app.url.actionui;

import javax.swing.JOptionPane;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import com.app.url.main.UrlMainWindow;
import com.app.url.panel.UrlLeftPanel;
import com.app.url.panel.right.UrlGoPanel;

public class FileCountAction {

	public void fileCountAction() {
		String selection1 = UrlGoPanel.getTextField().getText();
		int num = Integer.parseInt(UrlGoPanel.getCountField().getText());

		/*
		 * if (UrlTablePanel.tableModel.getRowCount() >= 0) { for (int i =
		 * UrlTablePanel.tableModel.getRowCount() - 1; i > -1; i--) {
		 * UrlTablePanel.tableModel.removeRow(i);
		 * 
		 * }
		 */

		for (int i = 0; i < num; i++) {
			try {
			//	URL url = new URL(selection1);
				DefaultMutableTreeNode subroot = new DefaultMutableTreeNode("" + selection1);
				DefaultTreeModel treeModel = UrlLeftPanel.getUrlTree().getTreeModel();
				DefaultMutableTreeNode root = (DefaultMutableTreeNode) treeModel.getRoot();
				int count = root.getChildCount();
				if (count <= 0) {
					count = 0;
				}
				System.out.println(count);
				treeModel.insertNodeInto(subroot, root, count);
				treeModel.reload();
				Thread.sleep(1050);

				HttpUrlConnectionFile h = new HttpUrlConnectionFile();
				h.httpUrlConnectionFile();

			} catch (Exception e1) {
				System.out.println(e1);
				e1.printStackTrace();
				JOptionPane.showMessageDialog(UrlMainWindow.fFrame, new String[] {
						"Unable to open due to wrong protocol (or) Only URL is required", selection1.toString() });

			}
		}
		System.out.println(num);
	}
	// }
}
