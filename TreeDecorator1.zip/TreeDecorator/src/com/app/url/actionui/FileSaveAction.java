package com.app.url.actionui;

import java.awt.event.ActionEvent;
import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractAction;

import com.app.url.util.ui.UiUtil;



/**
* Save the edits performed on the {@link CurrentPortfolio}, and update the display 
* to show that the <tt>CurrentPortfolio</tt> no longer needs a save.
*/
public final class FileSaveAction extends AbstractAction implements Observer {

  
  public FileSaveAction(String str) {
 super("Save");
	//  UiUtil.getImageIcon("/toolbarButtonGraphics/general/Save"); 
  }

  @Override public void actionPerformed(ActionEvent e) {
    //fLogger.info("Saving edits to the current portfolio.");
  }  
  
  
  @Override public void update(Observable aPublisher, Object aData) {
  } 
  
}
