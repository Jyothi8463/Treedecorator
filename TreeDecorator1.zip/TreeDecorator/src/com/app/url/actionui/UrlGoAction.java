package com.app.url.actionui;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import com.app.url.main.UrlMainWindow;
import com.app.url.panel.UrlLeftPanel;
import com.app.url.panel.right.UrlGoPanel;

public class UrlGoAction extends AbstractAction {

	List mp = new ArrayList<>();
	int count = 0;
	boolean path2 = true;

	public UrlGoAction() {
		super();

	}

	public UrlGoAction(String arg0, Icon arg1) {
		super(arg0, arg1);

	}

	public UrlGoAction(String arg0) {
		super(arg0);

	}

	@Override
	public void actionPerformed(ActionEvent event) {

		System.out.println("event --> " + event.getActionCommand());
		String selection = UrlGoPanel.getTextField().getText();
		String regex = "(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?(http://)?(https://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&\\n\\-=?\\+\\%/\\.\\w]+)?";
		boolean retVal = Pattern.matches(regex, selection);
		
		if (retVal == true) {

			if (UrlGoPanel.getCountField().getText().equals("")) {
				// try {
				// URL url = new URL(selection);

				if (!(mp.contains(selection.trim()))) {
					// URL url = new URL(selection);
					mp.add(selection.trim());
					System.out.println(selection.toString().trim());

					DefaultMutableTreeNode subroot = new DefaultMutableTreeNode("" + selection);
					// Build the tree up from the nodes we created.
					DefaultTreeModel treeModel = UrlLeftPanel.getUrlTree().getTreeModel();
					DefaultMutableTreeNode root = (DefaultMutableTreeNode) treeModel.getRoot();
					int count = root.getChildCount();
					if (count <= 0) {
						count = 0;
					}
					System.out.println(count);
					// Build the tree up from the nodes we created.
					treeModel.insertNodeInto(subroot, root, count);
					// .insertNodeInto(subroot, root, 0);
					treeModel.reload();

					HttpUrlConnectionFile h = new HttpUrlConnectionFile();
					h.httpUrlConnectionFile();

				} else {
					JOptionPane.showMessageDialog(UrlMainWindow.fFrame,
							new String[] { "url already exist", selection.toString() });
				}

			
			} else {
				int selectedOption = JOptionPane.showConfirmDialog(null, "Do you wanna continue?", "Choose",
						JOptionPane.YES_NO_OPTION);
				if (selectedOption == JOptionPane.YES_OPTION) {

					FileCountAction filecount = new FileCountAction();
					filecount.fileCountAction();
			
				}

			}
		} else {
			JOptionPane.showMessageDialog(UrlMainWindow.fFrame, new String[] {
					"Unable to open due to wrong protocol (or) Only URL is required", selection.toString() });
		}
	}
}

