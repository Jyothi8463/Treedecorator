package com.app.url.actionui;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JFrame;
import com.app.url.util.ui.UiUtil;

public class FileImportAction extends AbstractAction {

	public FileImportAction(String name,  JFrame aFrame) {
		 //   super("Open", UiUtil.getImageIcon("/toolbarButtonGraphics/general/Open")); 
			  super("Import", UiUtil.getEmptyIcon());
		    
		    putValue(SHORT_DESCRIPTION, "Import an existing portfolio");
		     
		  }
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
