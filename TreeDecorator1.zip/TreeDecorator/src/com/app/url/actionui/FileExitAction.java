package com.app.url.actionui;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;

import com.app.url.util.ui.UiUtil;



public final class FileExitAction extends AbstractAction {
  
  /**
  * Constructor.  
  * @param aCurrentPortfolio may have unsaved edits when this action is taken.
  * @param aEditSaver allows the user to save any unsaved edits.
  */
	
  public FileExitAction(String name ) {
    super("Exit", UiUtil.getEmptyIcon()); 
   
    putValue(SHORT_DESCRIPTION, "Close the application");
    //the windows ALT+F4 for File->Exit does not form part of the Java Look&Feel
    //putValue(
    //  ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_F4, ActionEvent.ALT_MASK) 
    //);
    putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_X) );    
    putValue(MNEMONIC_KEY, new Integer(KeyEvent.CTRL_DOWN_MASK) );    

  }

  @Override public void actionPerformed(ActionEvent event) {
	  
	  System.exit(0);
			  
  }

  
}