package com.app.url.actionui;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;
import com.app.url.panel.right.UrlGoPanel;
import com.app.url.panel.right.UrlRightMiddlePanel;
import com.app.url.panel.right.UrlTablePanel;

public class HttpUrlConnectionFile {

	Set mp = new HashSet<>();

	public void httpUrlConnectionFile() {
		
		HttpURLConnection con = null;
		try {
			String selection = UrlGoPanel.getTextField().getText();
			URL urls = new URL(selection);
			con = (HttpURLConnection) urls.openConnection();
			con.setRequestProperty("X-Cloupia-Request-Key", UrlGoPanel.getHeaderTextField().getText());
			// String responseHeader = ""+con.getResponseCode();
			int responsecode = con.getResponseCode();
		//	String resp1 = con.getInputStream().toString();
			String resp = con.getResponseMessage();

			System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" + "I am the resp:" + resp);
			System.out.println("------ i am header-------" + con.getHeaderFields());
			System.out.println(selection + "    ----- response is added-----   " + responsecode);
			System.out.println("hi Am here to row count  " + UrlTablePanel.getTableModel().getRowCount());
			System.out.println(selection.trim());
			System.out.println("***********************" + UrlGoPanel.textField.getName());

			if (responsecode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				String responseString = response.toString();
				UrlTablePanel.tableModel.fireTableDataChanged();
				UrlTablePanel.tableModel.addRow(new Object[] { selection, responsecode, responseString });
				System.out.println(responseString);

				UrlRightMiddlePanel.textarea.setText(responseString);
			}

		} catch (Exception e) {
			e.printStackTrace();
			// }

		}
	}

}
