package com.app.url.actionui;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

import com.app.url.util.ui.UiUtil;


//public final class FileCloseAction extends AbstractAction implements Observer {
public final class FileCloseAction extends AbstractAction implements Observer {


  /**
   * Constructor.
   * 
   * @param aCurrentPortfolio will be updated by this action to be untitled and empty of
   * stocks.
   * @param aEditSaver if <tt>aCurrentPortfolio</tt> has any unsaved edits, then
   * <tt>aEditSaver</tt> will offer the user the option of saving the edits.
   */
  public FileCloseAction(String name ) {
	//  public FileCloseAction(JFrame aParentFrame) {
    super("Close", UiUtil.getEmptyIcon());
    /*Args.checkForNull(aEditSaver);
    fCurrentPortfolio = aCurrentPortfolio;
    fCurrentPortfolio.addObserver(this);
    fEditSaver = aEditSaver;*/
    putValue(SHORT_DESCRIPTION, "Close the current portfolio");
    putValue(
      ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_W, ActionEvent.CTRL_MASK)
    );
    putValue(
      LONG_DESCRIPTION, "Close the current portfolio and display an empty set of stocks"
    );
    putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_C));
  }

  @Override public void actionPerformed(ActionEvent event) {
    //fLogger.info("Closing the current portfolio, and starting empty.");
    
  }

  /**
   * Synchronize the state of this object with the state of the {@link CurrentPortfolio}
   * passed to the constructor. This action is disabled only when the
   * <tt>CurrentPortfolio</tt> is untitled and does not need a save.
   */
  public void update(Observable aPublisher, Object aData) {
    
  }



  
}
