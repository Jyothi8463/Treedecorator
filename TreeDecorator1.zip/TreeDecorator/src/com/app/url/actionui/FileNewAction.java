package com.app.url.actionui;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.KeyStroke;

import com.app.url.util.ui.UiUtil;



public final class FileNewAction extends AbstractAction implements Observer{

/*	
	public FileNewAction(String name ) {
	    super("New", UiUtil.getEmptyIcon()); 
	}*/
 
  public FileNewAction(String str, JFrame aFrame ) {
  // super("New", UiUtil.getImageIcon("/resources/test.png")); 
	    super("New", UiUtil.getEmptyIcon()); 
	

   
    putValue(SHORT_DESCRIPTION, "Create a new portfolio");
    putValue(
      ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK) 
    );
    putValue(
      LONG_DESCRIPTION, "Create a new portfolio with given name and an empty set of stocks"
    );
    putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_N) );    
  }

  /**
  * Present dialog for the input of a name for the new <tt>Portfolio</tt>. 
  *
  * <P> The supplied name must have a non-zero trimmed length, and must not be the 
  * the same name as any currently stored <tt>Portfolio</tt>.
  * If the name entered by the user is invalid, then when <tt>OK</tt> is selected
  * an info box informs the users of the problem, and they 
  * are asked to enter another name.
  *
  * <P> If the <tt>CurrentPortfolio</tt> being replaced by this action has 
  * any unsaved edits, then allow the user the option of saving such edits.
  */
  @Override public void actionPerformed(ActionEvent event) {
    //fLogger.info("Start a new portfolio, with a unique name.");
    
  }  
  
 

  

  

 private void initNewPortfolio( String aNewName ){


  }

@Override
public void update(Observable o, Object arg) {
	// TODO Auto-generated method stub
	
}
}
