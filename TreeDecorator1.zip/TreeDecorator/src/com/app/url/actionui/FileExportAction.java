package com.app.url.actionui;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import com.app.url.panel.right.UrlTablePanel;
import com.app.url.util.ui.UiUtil;

public class FileExportAction extends AbstractAction {
	
	public FileExportAction() {
			  super("Export", UiUtil.getEmptyIcon());
		    
		    putValue(SHORT_DESCRIPTION, "Export an existing portfolio");
		     
		  }

	@Override
	public void actionPerformed(ActionEvent event) {
try{
			
			UrlTablePanel.exportTable(UrlTablePanel.table);

	}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
