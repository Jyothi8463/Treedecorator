package com.app.url.tree;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;

import com.app.url.main.UrlMainWindow;
import com.app.url.panel.UrlLeftPanel;

public class UrlTree extends JTree {
	UrlMainWindow mainWindow;
	UrlLeftPanel parentWindow ; 
	
	DefaultTreeModel treeModel;
	// create the root node
	DefaultMutableTreeNode root = null;

	

	public UrlTree(TreeNode arg0) {
		super(arg0);

	}

	public UrlTree(UrlMainWindow urlMainWindow, UrlLeftPanel urlLeftPanel) {
		
	}

	public UrlTree(UrlMainWindow urlMainWindow, UrlLeftPanel urlLeftPanel, DefaultTreeModel root) {
		super(root);
		
		//setRoot(root);
		setTreeModel(root);
		setParentWindow(urlLeftPanel);
		setMainWindow(urlMainWindow);
		//treeModel = new DefaultTreeModel(root);
		//add(treeModel);
		System.out.println("nnnnnnnnnnnnnnnnnnn");
	}

	/**
	 * @return the treeModel
	 */
	public DefaultTreeModel getTreeModel() {
		return treeModel;
	}

	/**
	 * @param treeModel the treeModel to set
	 */
	public void setTreeModel(DefaultTreeModel treeModel) {
		this.treeModel = treeModel;
	}

	/**
	 * @return the root
	 */
	public DefaultMutableTreeNode getRoot() {
		return root;
	}

	/**
	 * @param root the root to set
	 */
	public void setRoot(DefaultMutableTreeNode root) {
		this.root = root;
	}

	/**
	 * @return the mainWindow
	 */
	public UrlMainWindow getMainWindow() {
		return mainWindow;
	}

	/**
	 * @param mainWindow the mainWindow to set
	 */
	public void setMainWindow(UrlMainWindow mainWindow) {
		this.mainWindow = mainWindow;
	}

	/**
	 * @return the parentWindow
	 */
	public UrlLeftPanel getParentWindow() {
		return parentWindow;
	}

	/**
	 * @param parentWindow the parentWindow to set
	 */
	public void setParentWindow(UrlLeftPanel parentWindow) {
		this.parentWindow = parentWindow;
	}
	
	

}
