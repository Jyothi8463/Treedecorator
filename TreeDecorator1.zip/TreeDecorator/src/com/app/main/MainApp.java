package com.app.main;

import com.app.url.main.UrlMainWindow;

public class MainApp {
	public static void main(String[] args) {
		UrlMainWindow window = new UrlMainWindow();
	
		}
}
